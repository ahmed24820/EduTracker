package com.Graduation.EduTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
